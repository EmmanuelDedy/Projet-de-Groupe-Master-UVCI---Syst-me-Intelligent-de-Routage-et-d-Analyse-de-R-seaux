var struct_chemin =
[
    [ "bande_passante_min", "struct_chemin.html#a5c86f06e708953bfed14aef45ccd3156", null ],
    [ "cout_total", "struct_chemin.html#a19ac368ad526034b581cef5e0bfd3886", null ],
    [ "latence_totale", "struct_chemin.html#a508037535aaaf0d3335d53dc31ff4276", null ],
    [ "longueur", "struct_chemin.html#ac75550e412ee627165a15c3e65f20c1d", null ],
    [ "noeuds", "struct_chemin.html#a95532be55c6268b4d75931fbbf03d37b", null ],
    [ "securite_min", "struct_chemin.html#aed61181a645cd34b9488467883053271", null ]
];