var backtracking_8c =
[
    [ "Context", "struct_context.html", "struct_context" ],
    [ "contient", "backtracking_8c.html#a332ad0b3cf1a41a5f452fb6fd1435923", null ],
    [ "explorer", "backtracking_8c.html#ab5c009fb6e579070ddda28585fe7ba4b", null ],
    [ "routage_backtracking_contraint", "backtracking_8c.html#af774ccbdbe171c882ea576d0812cf076", null ]
];