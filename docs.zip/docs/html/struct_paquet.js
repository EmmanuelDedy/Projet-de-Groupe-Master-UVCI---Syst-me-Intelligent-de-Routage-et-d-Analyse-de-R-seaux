var struct_paquet =
[
    [ "destination", "struct_paquet.html#a7b11f0bed8ed9199ab103164803c3bf6", null ],
    [ "id", "struct_paquet.html#a85e3ab6ec2d4c0bce1825f746df619ff", null ],
    [ "precedent", "struct_paquet.html#a3683ee4a4b3bf97b703bb2a4da2e7a3b", null ],
    [ "priorite", "struct_paquet.html#a8651669edfbe5d4a5b3dcc62515e6acb", null ],
    [ "source", "struct_paquet.html#a36e3c5b6219541ea080cbd8fa3e29cfc", null ],
    [ "suivant", "struct_paquet.html#a028e7e4b4eff86e3df3d38be68b7e594", null ],
    [ "taille_Mo", "struct_paquet.html#a893ad1cd7399eaf418501886f35b4c52", null ],
    [ "temps_arrivee", "struct_paquet.html#a313962014f7b18aff342e7f71ba16dc7", null ]
];