var searchData=
[
  ['backtracking_2ec_0',['backtracking.c',['../backtracking_8c.html',1,'']]],
  ['backtracking_2eh_1',['backtracking.h',['../backtracking_8h.html',1,'']]]
];
