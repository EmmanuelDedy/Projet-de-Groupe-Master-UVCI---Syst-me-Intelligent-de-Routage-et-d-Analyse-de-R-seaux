var struct_metriques =
[
    [ "bande_passante", "struct_metriques.html#af82d8dbbe7806b04907d672e18cb12f2", null ],
    [ "cout", "struct_metriques.html#ab7c69a08304787bc9e2cff02a98572ab", null ],
    [ "fiabilite", "struct_metriques.html#af060da2a4487619bbd933ed866d72a8b", null ],
    [ "latence", "struct_metriques.html#acdfcc2cf1099f9bfeb474d505b2aacb7", null ],
    [ "securite", "struct_metriques.html#a71f6b2d4a14d89cb07983d651a9c514c", null ]
];