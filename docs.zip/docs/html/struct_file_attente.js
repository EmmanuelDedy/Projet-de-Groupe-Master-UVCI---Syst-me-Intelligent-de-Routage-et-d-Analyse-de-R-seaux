var struct_file_attente =
[
    [ "capacite_max", "struct_file_attente.html#accb6998125b71aacbf79a51ae4240fac", null ],
    [ "paquets_defiles", "struct_file_attente.html#ad04517c9e6bac348357c9bff446b58e5", null ],
    [ "paquets_rejetes", "struct_file_attente.html#afbdb5cb25ea33ea63775cbf19a71e78c", null ],
    [ "paquets_total", "struct_file_attente.html#ae78e5686f7fb62060a13bfb532ecd376", null ],
    [ "queue", "struct_file_attente.html#a0968bbdc6d8a86f0197937db9c685a3c", null ],
    [ "somme_attente", "struct_file_attente.html#adefb0511323362afef17521f521ce490", null ],
    [ "taille_actuelle", "struct_file_attente.html#a1ac0c3e0468ba2bbdfcbf4efd1fa7482", null ],
    [ "tete", "struct_file_attente.html#ae8c5320d52ea6601f3469e8343d35cd4", null ]
];