var searchData=
[
  ['g_0',['g',['../struct_context.html#a418d6d9523f31f28b7a8ef624513c9b2',1,'Context']]]
];
