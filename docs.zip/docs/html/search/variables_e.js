var searchData=
[
  ['visite_0',['visite',['../struct_context.html#a3cf78a0f35d10c478868b075f2a3274f',1,'Context']]]
];
