var indexSectionsWithContent =
{
  0: "123456789:abcdefghijklmnopqrstuvxyzàé📄",
  1: "acefgmnp",
  2: "bdglmrsu",
  3: "acdefgijlmoprsu",
  4: "bcdefgilmnpqstvxy",
  5: "t",
  6: "cprs",
  7: "m",
  8: "123456789:abcdefghijklmopqrstuvyzàé📄"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "defines",
  8: "pages"
};

var indexSectionLabels =
{
  0: "Tout",
  1: "Structures de données",
  2: "Fichiers",
  3: "Fonctions",
  4: "Variables",
  5: "Énumérations",
  6: "Valeurs énumérées",
  7: "Macros",
  8: "Pages"
};

