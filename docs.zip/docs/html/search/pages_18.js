var searchData=
[
  ['page_20de_20garde_0',['1. Page de Garde',['../rapport_projet.html#rap_garde',1,'']]],
  ['par_20rapport_20à_20l_20existant_1',['8.2 Apport par rapport à l&apos;existant',['../rapport_projet.html#rap_apport',1,'']]],
  ['performance_20comparatives_2',['7.2 Mesures de Performance Comparatives',['../rapport_projet.html#rap_perf',1,'']]],
  ['perspectives_20d_20amélioration_3',['8.3 Perspectives d&apos;Amélioration',['../rapport_projet.html#rap_perspectives',1,'']]],
  ['plus_20courts_20chemins_20routage_5fk_5fchemins_4',['3. Module Routage : K-Plus Courts Chemins (&lt;span class=&quot;tt&quot;&gt;routage_k_chemins&lt;/span&gt;)',['../rapport_projet.html#autotoc_md22',1,'']]],
  ['plus_20courts_20chemins_20yen_20simplifié_5',['5.3 K-Plus Courts Chemins (Yen Simplifié)',['../rapport_projet.html#rap_proof_yen',1,'']]],
  ['points_20d_20articulation_20identifier_5fpoints_5fcritiques_6',['5. Module Sécurité : Points d&apos;Articulation (&lt;span class=&quot;tt&quot;&gt;identifier_points_critiques&lt;/span&gt;)',['../rapport_projet.html#autotoc_md24',1,'']]],
  ['pour_20dijkstra_7',['2. Tableau vs Tas Binaire (Binary Heap) pour Dijkstra',['../rapport_projet.html#autotoc_md17',1,'']]],
  ['préfixes_8',['B. Légende des Préfixes',['../rapport_projet.html#autotoc_md31',1,'']]],
  ['prérequis_9',['Prérequis',['../index.html#sub_req',1,'']]],
  ['priorité_10',['La File à Priorité',['../index.html#struct_pq',1,'']]],
  ['priorité_20enfiler_11',['7. Module Simulation : File à Priorité (&lt;span class=&quot;tt&quot;&gt;enfiler&lt;/span&gt;)',['../rapport_projet.html#autotoc_md26',1,'']]],
  ['priorité_20simulation_20qos_12',['C. File à Priorité (Simulation QoS)',['../rapport_projet.html#autotoc_md14',1,'']]],
  ['projet_13',['Objectifs du Projet',['../rapport_projet.html#rap_objectifs',1,'']]],
  ['projet_20de_20fin_20de_20semestre_14',['📄 Rapport Technique (Projet de Fin de Semestre)',['../rapport_projet.html',1,'']]],
  ['protocole_20de_20test_15',['7.1 Protocole de Test',['../rapport_projet.html#rap_proto',1,'']]],
  ['python_20java_16',['1. Langage C vs Python/Java',['../rapport_projet.html#autotoc_md16',1,'']]]
];
